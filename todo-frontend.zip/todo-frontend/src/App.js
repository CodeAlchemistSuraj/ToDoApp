import React, { useState } from 'react';
import TaskList from './components/TaskList';
import TaskForm from './components/TaskForm';
import './App.css';

function App() {
  const [refresh, setRefresh] = useState(false);

  const handleTaskCreated = () => {
    setRefresh(!refresh);
  };

  return (
    <div className="app">
      <div className="container">
        <h1>Todo App</h1>
        <TaskForm onTaskCreated={handleTaskCreated} />
        <TaskList refresh={refresh} />
      </div>
    </div>
  );
}

export default App;