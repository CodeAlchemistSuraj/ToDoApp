import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './TaskForm.css';

function TaskForm({ onTaskCreated, taskToEdit }) {
  const [task, setTask] = useState({
    title: '',
    description: '',
    status: 'TODO',
  });
  const [error, setError] = useState('');

  useEffect(() => {
    if (taskToEdit) {
      setTask(taskToEdit);
    }
  }, [taskToEdit]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTask({ ...task, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    try {
      if (taskToEdit) {
        await axios.put(`http://localhost:8080/api/tasks/${task.id}`, task);
      } else {
        await axios.post('http://localhost:8080/api/tasks', task);
      }
      setTask({ title: '', description: '', status: 'TODO' });
      onTaskCreated();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save task');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="task-form">
      {error && <div className="error">{error}</div>}
      <div className="form-group">
        <label>Title</label>
        <input
          type="text"
          name="title"
          value={task.title}
          onChange={handleChange}
          required
          maxLength={100}
        />
      </div>
      <div className="form-group">
        <label>Description</label>
        <textarea
          name="description"
          value={task.description}
          onChange={handleChange}
          maxLength={500}
        />
      </div>
      <div className="form-group">
        <label>Status</label>
        <select name="status" value={task.status} onChange={handleChange}>
          <option value="TODO">TODO</option>
          <option value="IN_PROGRESS">In Progress</option>
          <option value="DONE">Done</option>
        </select>
      </div>
      <button type="submit">
        {taskToEdit ? 'Update Task' : 'Add Task'}
      </button>
    </form>
  );
}

export default TaskForm;