import React, { useState, useEffect } from 'react';
import axios from 'axios';
import TaskForm from './TaskForm';
import './TaskList.css';

function TaskList({ refresh }) {
  const [tasks, setTasks] = useState([]);
  const [error, setError] = useState('');
  const [editingTask, setEditingTask] = useState(null);

  useEffect(() => {
    fetchTasks();
  }, [refresh]);

  const fetchTasks = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/tasks');
      setTasks(response.data);
      setError('');
    } catch (err) {
      setError('Failed to fetch tasks');
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:8080/api/tasks/${id}`);
      setTasks(tasks.filter((task) => task.id !== id));
    } catch (err) {
      setError('Failed to delete task');
    }
  };

  const handleEdit = (task) => {
    setEditingTask(task);
  };

  const handleTaskUpdated = () => {
    setEditingTask(null);
    fetchTasks();
  };

  return (
    <div className="task-list">
      {error && <div className="error">{error}</div>}
      {editingTask && (
        <TaskForm taskToEdit={editingTask} onTaskCreated={handleTaskUpdated} />
      )}
      {tasks.length === 0 && <p className="no-tasks">No tasks available.</p>}
      {tasks.map((task) => (
        <div key={task.id} className="task-item">
          <div className="task-content">
            <h3>{task.title}</h3>
            <p>{task.description}</p>
            <p className="status">Status: {task.status}</p>
          </div>
          <div className="task-actions">
            <button onClick={() => handleEdit(task)} className="edit-btn">
              Edit
            </button>
            <button onClick={() => handleDelete(task.id)} className="delete-btn">
              Delete
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

export default TaskList;